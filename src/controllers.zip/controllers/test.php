<?php

require_once "vadersentiment.php";

$textToTest = "VADER is smart, handsome, and funny.";

$sentimenter = new SentimentIntensityAnalyzer();
$result = $sentimenter->getSentiment($textToTest);
$textToTest = $textToTest.$result["compound"];

echo $textToTest."\n";
// print_r($textToTest.$result["compound"]);

?>